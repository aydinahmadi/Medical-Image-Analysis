import cv2
import numpy as np
from skimage.filters import hessian
import matplotlib.pyplot as plt

def post_process(img, base_offset):
    no_retina_img = img.copy()
    circle = np.zeros(img.shape, np.uint8)
    offset = 0
    detections = []
    while True:
        detections = cv2.HoughCircles(no_retina_img, cv2.HOUGH_GRADIENT, 1.5, base_offset + offset)
        if detections is None:
            return no_retina_img
        if len(detections[0]) == 1:
            break
        offset += 100
    for (x, y, r) in detections[0]:
        cv2.circle(circle, (int(x), int(y)), int(r), (255, 255, 255), 40)
    no_retina_img = no_retina_img - circle
    return no_retina_img

def remove_noise(img, min_size):
    nb_components, output, stats, centroids = cv2.connectedComponentsWithStats(img, connectivity=8)
    sizes = stats[1:, -1]
    clear_img = np.zeros((img.shape[0], img.shape[1]), np.uint8)
    for i in range(0, nb_components - 1):
        if sizes[i] >= min_size:
            clear_img[output == i + 1] = 255
    return clear_img

def remove_background(img, mask):
    new_image = np.zeros((img.shape[0], img.shape[1]), np.uint8)
    new_image[mask == 0] = img[mask == 0]
    return new_image

def invert(img):
    return 255 - img

def get_mask(img, threshold=5):

    img = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
    img_mask = np.zeros((img.shape[0], img.shape[1]), np.uint8)
    img_mask[img < threshold] = 255
    return img_mask

def evaluation(gold, img):

    gold = gold.flatten()
    img = img.flatten()

    TP = ((gold == 255) & (img == 255)).sum()
    FP = ((gold != 255) & (img == 255)).sum()
    FN = ((gold == 255) & (img != 255)).sum()

    precision = TP / (TP + FP) if (TP + FP) > 0 else 0
    recall = TP / (TP + FN) if (TP + FN) > 0 else 0
    f_score = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0

    return precision, recall, f_score


if __name__ == '__main__':
    filepath = 'fundus/d11_g.jpg'
    img = cv2.imread(filepath, 2)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    masked_img = get_mask(img, 10)
    _, img, _ = cv2.split(img)
    img = invert(img)
    bck_img = remove_background(img, masked_img)
    img = cv2.equalizeHist(bck_img)
    img = hessian(img)
    img = remove_background(img, masked_img)
    filtered_img = cv2.bilateralFilter(img, 7, 25, 25)
    clear_img = remove_noise(filtered_img, 300)
    result = post_process(clear_img, 1000)


    gold = cv2.imread('fundus/d11_g_gold.png', 2)
    gold[gold == 1] = 255
    gold[gold == 0] = 0

    # plot
    plt.subplot(1, 2, 1)
    plt.imshow(result, cmap='gray')
    plt.title("result")

    plt.subplot(1, 2, 2)
    plt.imshow(gold, cmap='gray')
    plt.title("gold")
    plt.show()

    precision, recall, Fscore = evaluation(gold, result)
    print('evaluation:\n')
    print(f'Precision: {precision:.2f}')
    print(f'Recall: {recall:.2f}')
    print(f'Fscore: {Fscore:.2f}')
