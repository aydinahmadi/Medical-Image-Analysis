import copy
import cv2
import numpy as np
from PIL import Image, ImageEnhance
import matplotlib.pyplot as plt
from scipy import ndimage
from skimage.feature import peak_local_max
import matplotlib.colors as colors

def preprocess(image_path:str):

    image = cv2.imread(image_path, 2)
    image = cv2.fastNlMeansDenoising(image, None, 3, 5, 21)
    image = Image.fromarray(image)
    contrasted_image = ImageEnhance.Contrast(image)
    image = contrasted_image.enhance(1.5)
    image = np.asarray(image)
    image = cv2.GaussianBlur(image, (3, 3), 0)

    return image


def mask(image):
    _, masked_image = cv2.threshold(image, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    kernel = np.ones((15, 15), np.uint8)
    masked_image = cv2.morphologyEx(masked_image, cv2.MORPH_CLOSE, kernel)
    kernel = np.ones((17, 17), np.uint8)
    masked_image = cv2.dilate(masked_image, kernel)
    masked_image = ndimage.binary_fill_holes(masked_image).astype('uint8')
    kernel = np.ones((15, 15), np.uint8)
    masked_image = cv2.morphologyEx(masked_image, cv2.MORPH_OPEN, kernel)
    kernel = np.ones((5, 5), np.uint8)
    masked_image = cv2.dilate(masked_image, kernel)
    masked_image = ndimage.binary_fill_holes(masked_image).astype('uint8')
    kernel = np.ones((23, 23), np.uint8)
    masked_image = cv2.erode(masked_image, kernel)
    row, col = masked_image.shape
    return row, col, masked_image


def evaluation_part1(mask, gmask, rows, cols):
    TP = 0
    FP = 0
    FN = 0
    for r in range(rows):
        for c in range(cols):
            if mask[r][c] == 1 and gmask[r][c] == 1:
                TP += 1
            if mask[r][c] == 1 and gmask[r][c] == 0:
                FP += 1
            if mask[r][c] == 0 and gmask[r][c] == 1:
                FN += 1

    precision = TP / (TP + FP)
    recall = TP / (TP + FN)
    fscore = TP / (TP + (1/2 * (FP + FN)))

    return precision, recall, fscore

def part2_preprocess(image, row, col):
    for r in range(row):
        for c in range(col):
            if image[r][c] > 200:
                image[r][c] = 255
            else:
                image[r][c] = 0
    return image


def distance_transform(image, masked_image, row, col):

    kernel = np.ones((3, 3), np.uint8)
    erosion = cv2.erode(image, kernel)
    new_masked_image = copy.deepcopy(masked_image)
    for r in range(row):
        for c in range(col):
            if erosion[r][c] == 255:
                new_masked_image[r][c] = 0

    img = cv2.distanceTransform(new_masked_image, cv2.DIST_L2, 3)
    cv2.normalize(img, img, 0, 1.0, cv2.NORM_MINMAX)
    coordinates = peak_local_max(img, min_distance=14)
    cells = []
    for x, y in coordinates:
        cells = np.append(cells, data_gold_cell[x][y])
    return cells, coordinates, img


def evaluation_part2(cells, gold_cell):
    val = 1000
    TP = 0
    duplicate = 0
    cells = np.sort(cells)
    cells = cells[cells != 0]
    for c in range(cells.size):
        if val != cells[c]:
            TP -= duplicate
            duplicate = 0
            TP += 1
        if val == cells[c]:
            duplicate = 1
        val = cells[c]

    TP -= duplicate
    precision = TP / cells.size             # cell size is equal to TP + FP
    recall = TP / gold_cell.max()           # TP + FN actually means how many cells we have
                                            # so max of colored_img will give us all number of cells
    Fscore = (2 * precision * recall) / (precision + recall)

    return precision, recall, Fscore


def get_neighbors(coor, cell):
    neighbor = [[cell, int(coor[0]), int(coor[1])]]
    for c in range(-1, 2):
        for d in range(-1, 2):
            if c == 0 and d == 0:
                continue
            neighbor.append([cell, int(coor[0]) + c * 3, int(coor[1]) + d * 3])
    return neighbor

def segment_cells(image, coordinates):
    regions = []
    for cell_id, coor in enumerate(coordinates):
        regions.extend(get_neighbors(coor, cell_id + 1))

    checked = []
    image = np.pad(image, ((3, 3), (3, 3)), 'constant')

    while regions:
        e, x, y = regions.pop(0)
        checked.append((e, x, y))
        if image[x + 3][y + 3] == -1:
            for c in range(-2, 3):
                for d in range(-2, 3):
                    image[x + c + 3][y + d + 3] = e
            neighbors = get_neighbors([x, y], e)
            for neighbor in neighbors:
                if neighbor not in checked:
                    regions.append(neighbor)

    image = image[3:-3, 3:-3]
    image[image == -1] = 0
    return image


def evaluation_part3(coordinates, rows, cols, gold_data, image):
    scores_dice = []
    scores_iou = []

    for c in range(coordinates.shape[0]):
        TP, FP, FN = 0, 0, 0
        cell = -1

        for row in range(rows):
            for col in range(cols):
                if cell == -1 and gold_data[row][col] != 0 and image[row][col] == c + 1:
                    cell = gold_data[row][col]

                if cell == gold_data[row][col]:
                    if image[row][col] == c + 1:
                        TP += 1
                    else:
                        FN += 1
                elif image[row][col] == c + 1:
                    FP += 1

        dice_score = (2 * TP) / (2 * TP + FN + FP)
        iou_score = TP / (TP + FN + FP)

        scores_dice.append(dice_score)
        scores_iou.append(iou_score)

    threshs = [0.5, 0.75, 0.9]
    thresh_counts_dice = [len([s for s in scores_dice if s > t]) for t in threshs]
    thresh_counts_iou = [len([s for s in scores_iou if s > t]) for t in threshs]

    print('Part 3 evaluations:')
    for i, t in enumerate(threshs):
        print(f'Threshold {t}:')
        print(f'Dice: {thresh_counts_dice[i] / len(scores_dice):.2f}')
        print(f'IoU: {thresh_counts_iou[i] / len(scores_iou):.2f}\n')


if __name__ == '__main__':

    image_path = "data/im3.jpg"
    gold_mask = "data/im3_gold_mask.txt"
    gold_cell = "data/im3_gold_cells.txt"

    data_gold_mask = np.loadtxt(gold_mask)
    data_gold_cell = np.loadtxt(gold_cell)
    #preprocessing
    image = preprocess(image_path)
    #mask
    row, col, masked_image = mask(image)

    # evaluation part 1
    print('Part 1 evaluations:')

    precision, recall, fscore = evaluation_part1(masked_image, data_gold_mask, row, col)
    print(f'precision: {precision:.2f}\nrecall: {recall:.2f}\nfscore: {fscore:.2f}')

    # plot part 1
    plt.xticks([]), plt.yticks([])
    plt.imshow(masked_image, cmap='gray')
    plt.show()

    # preprocess for part 2
    image2 = part2_preprocess(image, row, col)

    cells, coordinates, img = distance_transform(image2, masked_image, row, col)

    # plot part 2
    plt.xticks([]), plt.yticks([])
    plt.plot(coordinates[:, 1], coordinates[:, 0], 'ro', markersize=3)
    plt.imshow(img, cmap='gray')
    plt.show()

    #evaluation part 2
    precision, recall, Fscore = evaluation_part2(cells, data_gold_cell)
    print('Part 2 evaluations:')
    print(f'Precision: {precision:.2f}')
    print(f'Recall: {recall:.2f}')
    print(f'Fscore: {Fscore:.2f}')


    #part 3
    tmp = copy.deepcopy(masked_image)
    tmp = tmp.astype(int)
    tmp[tmp == 1] = -1
    labeled_img = segment_cells(tmp, coordinates)

    #plot part 3
    cmap = plt.cm.get_cmap('hsv', np.max(labeled_img) + 1)
    cmap_colors = cmap(np.arange(np.max(labeled_img) + 1))
    cmap_colors[0] = [0, 0, 0, 1]
    colormap = colors.ListedColormap(cmap_colors)
    norm = colors.Normalize(vmin=0, vmax=np.max(labeled_img))
    plt.imshow(labeled_img, cmap=colormap, norm=norm)
    plt.show()

    #evaluation part 3
    evaluation_part3(coordinates, row, col, data_gold_cell, labeled_img)
