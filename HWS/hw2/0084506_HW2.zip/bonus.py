import numpy as np
import matplotlib.pyplot as plt
from skimage.io import imread
from sklearn.cluster import KMeans
import cv2

def plot_image(image):
    cmap = plt.cm.get_cmap('tab10', int(np.max(image)) + 1)

    plt.imshow(image, cmap=cmap, vmin=0, vmax=np.max(image))

    plt.colorbar()

    plt.show()


image = imread('nucleus-dataset/test_1.png', as_gray=True)

img2 = image.reshape(-1)
orientations = 8
scales = [0.1, 0.5, 1.0]
kernels = []
for theta in range(8):
    theta = theta / 4. * np.pi
    for sigma in (1, 3, 5, 7):
        for lamda in np.arange(0, np.pi, np.pi / 4):
            for gamma in (0.05, 0.5):
                ksize = 15
                phi = 0.5
                kernel = cv2.getGaborKernel((ksize, ksize), sigma, theta, lamda, gamma, phi, ktype=cv2.CV_64F)
                kernels.append(kernel)


filtered_images = []
for kernel in kernels:
    filtered_image = cv2.filter2D(img2, -1, kernel)
    filtered_images.append(np.abs(filtered_image))
features = np.vstack([filtered_image.flatten() for filtered_image in filtered_images]).reshape(-1, len(kernels))
features = np.nan_to_num(features, nan=0)
print(features.shape)

num_clusters = 5
kmeans = KMeans(n_clusters=num_clusters)
kmeans.fit(features)
labels = kmeans.labels_
print(labels.shape)
print(set(labels))
labels = labels.reshape(image.shape)
plot_image(labels)
